import pandas as pd
import numpy as np

# Student Performance Analysis System: 5 students, 3 subjects
df = pd.read_csv("student_performance.csv")
subjects = ["Python", "DBMS", "Cybersecurity"]

print("STUDENT DATA")
print(df.to_string(index=False))

# NumPy calculations
marks = df[subjects].to_numpy()
df["Total_Marks"] = np.sum(marks, axis=1)
df["Average_Marks"] = np.mean(marks, axis=1).round(2)

def assign_grade(average):
    if average >= 90:
        return "A+"
    elif average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 50:
        return "D"
    return "F"

df["Grade"] = df["Average_Marks"].apply(assign_grade)

# Pass rule: at least 40 in every subject and attendance >= 75%
def check_result(row):
    for subject in subjects:
        if row[subject] < 40:
            return "Fail"
    if row["Attendance"] < 75:
        return "Fail"
    return "Pass"

df["Result"] = df.apply(check_result, axis=1)

columns = [
    "Student_ID", "Name", "Department", "Python", "DBMS",
    "Cybersecurity", "Attendance", "Total_Marks",
    "Average_Marks", "Grade", "Result"
]

print("\nFINAL STUDENT PERFORMANCE REPORT")
print(df[columns].sort_values("Average_Marks", ascending=False).to_string(index=False))

top_student = df.loc[df["Average_Marks"].idxmax()]
lowest_student = df.loc[df["Average_Marks"].idxmin()]
print("\nCLASS SUMMARY")
print(f"Top-performing student: {top_student['Name']} ({top_student['Average_Marks']:.2f})")
print(f"Lowest-performing student: {lowest_student['Name']} ({lowest_student['Average_Marks']:.2f})")
print(f"Class average: {np.mean(df['Average_Marks']):.2f}")

print("\nSUBJECT-WISE ANALYSIS")
for subject in subjects:
    print(f"{subject}: Average = {df[subject].mean():.2f}, Highest = {df[subject].max()}, Lowest = {df[subject].min()}")

pass_count = (df["Result"] == "Pass").sum()
fail_count = (df["Result"] == "Fail").sum()
print("\nPASS/FAIL STATISTICS")
print(f"Pass students: {pass_count}")
print(f"Fail students: {fail_count}")
print(f"Pass percentage: {(pass_count / len(df)) * 100:.2f}%")

df[columns].sort_values("Average_Marks", ascending=False).to_csv(
    "student_performance_result.csv", index=False
)
print("\nReport saved as student_performance_result.csv")

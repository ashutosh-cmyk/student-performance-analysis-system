# Student Performance Analysis System

A beginner-friendly Python project analyzing marks and attendance for 5 students across 3 subjects.

## Technologies
- Python
- NumPy
- Pandas

## Features
- Total and average marks using NumPy
- Grade assignment with a reusable function
- Pass/fail check
- Highest, lowest, and class-average performance
- Subject-wise analysis and pass percentage
- Exports a final report as CSV

## Files
- `student_performance_analysis.py` — main program
- `student_performance.csv` — sample dataset
- `README.md` — project documentation

## How to run
1. Install dependencies: `pip install pandas numpy`
2. Keep the Python file and CSV in the same folder.
3. Run: `python student_performance_analysis.py`

Sample pass rule: at least 40 marks in every subject and attendance of at least 75%. Change it if your teacher specifies a different rule.
